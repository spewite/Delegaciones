﻿Public Class Gestion
    Private Sub Gestion_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
        Me.ControlBox = False
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub
End Class