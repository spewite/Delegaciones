﻿Public Class Facturas
    Private Sub Facturas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
        Me.ControlBox = False
    End Sub
End Class